# HRM-Trained MLP Surrogate for PODE Auto-Ignition — Reproducibility Dataset Package

## Status
This package contains a synthetic HRM-style dataset generated according to the manuscript variables and qualitative ignition behaviour of PODE3/PODE4 auto-ignition. It is intended as a reproducibility scaffold for reviewer-response preparation.

Important: this is not an experimentally validated or Cantera-generated HRM dataset. If actual HRM simulation files become available, replace the CSV files in `dataset/` with the real outputs before final submission.

## Files
- `dataset/train.csv`: training split
- `dataset/validation.csv`: validation split
- `dataset/test.csv`: test split
- `dataset/dataset_summary.csv`: split-level summary
- `config/dataset_config.json`: operating ranges, features, targets, and split details
- `scripts/`: placeholder scripts for dataset generation, training, testing, and benchmarking
- `models/`: folder reserved for trained MLP weights

## MLP input features
The manuscript-defined CFD-compatible inputs are:
- `PODEn`
- `Yc`
- `Z`
- `H_norm`

Supporting columns included for traceability:
- `phi`
- `T0_K`
- `P0_bar`

## Targets
The target outputs are:
- Thermodynamic network f1: `T_K`, `P_bar`
- Product-species network f2: `YCO`, `YCO2`, `YH2O`
- Educt-species network f3: `YPODE`, `YO2`
- HRR network f4: `HRR_MW_m3`

## Suggested Data Availability wording
The HRM-generated dataset, trained model weights, scripts, configuration files, and README instructions are publicly available at: [GitHub/Zenodo link to be inserted].

If using this scaffold instead of actual HRM output, do not describe it as experimental or validated HRM data.
